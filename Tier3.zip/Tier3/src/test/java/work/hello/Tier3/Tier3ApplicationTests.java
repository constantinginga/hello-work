package work.hello.Tier3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tier3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
