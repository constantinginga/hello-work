package work.hello.Tier3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tier3Application {

	public static void main(String[] args) {
		SpringApplication.run(Tier3Application.class, args);
	}

}
